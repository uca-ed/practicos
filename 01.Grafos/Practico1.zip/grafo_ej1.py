import csv
import json

class Grafo:
    def __init__(self, nodos=None, matriz=None):
        self.nodos = nodos if nodos else []
        self.num_nodos = len(self.nodos)
        self.matriz = matriz if matriz else []
        self.nodo_a_indice = {nodo: i for i, nodo in enumerate(self.nodos)}
    
    @classmethod
    def desde_csv(cls, archivo_csv):
        matriz = []
        with open(archivo_csv, 'r', encoding='utf-8') as archivo:
            lector = csv.reader(archivo)
            for fila in lector:
                if fila and any(cell.strip() for cell in fila):
                    matriz.append([int(cell.strip()) for cell in fila if cell.strip()])
        
        num_nodos = len(matriz)
        nodos = [str(i) for i in range(num_nodos)]
        return cls(nodos, matriz)
    
    @classmethod
    def desde_json(cls, archivo_json):
        with open(archivo_json, 'r', encoding='utf-8') as archivo:
            datos = json.load(archivo)
        
        nodos = datos['P']
        vecindades = datos['E']
        num_nodos = len(nodos)
        
        matriz = [[0 for _ in range(num_nodos)] for _ in range(num_nodos)]
        nodo_a_indice = {nodo: i for i, nodo in enumerate(nodos)}
        
        for nodo_origen, vecinos in vecindades.items():
            if nodo_origen in nodo_a_indice:
                i = nodo_a_indice[nodo_origen]
                for vecino in vecinos:
                    if vecino in nodo_a_indice:
                        j = nodo_a_indice[vecino]
                        matriz[i][j] = 1
        
        return cls(nodos, matriz)
    
    def obtener_minimales(self):
        minimales = set()
        
        for j in range(self.num_nodos):
            es_minimal = True
            for i in range(self.num_nodos):
                if self.matriz[i][j] == 1:
                    es_minimal = False
                    break
            
            if es_minimal:
                minimales.add(self.nodos[j])
        
        return minimales
    
    def obtener_maximales(self):
        maximales = set()
        
        for i in range(self.num_nodos):
            es_maximal = True
            for j in range(self.num_nodos):
                if self.matriz[i][j] == 1:
                    es_maximal = False
                    break
            
            if es_maximal:
                maximales.add(self.nodos[i])
        
        return maximales
    
    def vecindad_derecha(self, nodo):
        if nodo not in self.nodo_a_indice:
            return set()
        
        i = self.nodo_a_indice[nodo]
        vecindad = set()
        
        for j in range(self.num_nodos):
            if self.matriz[i][j] == 1:
                vecindad.add(self.nodos[j])
        
        return vecindad
    
    def vecindad_izquierda(self, nodo):
        if nodo not in self.nodo_a_indice:
            return set()
        
        j = self.nodo_a_indice[nodo]
        vecindad = set()
        
        for i in range(self.num_nodos):
            if self.matriz[i][j] == 1:
                vecindad.add(self.nodos[i])
        
        return vecindad
    
    def imprimir_matriz(self):
        print("Matriz de adyacencia:")
        print("    ", end="")
        for nodo in self.nodos:
            print(f"{nodo:>3}", end=" ")
        print()
        
        for i, nodo in enumerate(self.nodos):
            print(f"{nodo:>3}:", end=" ")
            for j in range(self.num_nodos):
                print(f"{self.matriz[i][j]:>3}", end=" ")
            print()
    
    def imprimir_info(self):
        print(f"Grafo con {self.num_nodos} nodos: {self.nodos}")
        print()
        self.imprimir_matriz()
        print()
        
        minimales = self.obtener_minimales()
        maximales = self.obtener_maximales()
        
        print(f"Nodos minimales: {sorted(minimales) if minimales else 'Ninguno'}")
        print(f"Nodos maximales: {sorted(maximales) if maximales else 'Ninguno'}")
        print()
        
        print("Vecindades derechas:")
        for nodo in self.nodos:
            vecindad = self.vecindad_derecha(nodo)
            print(f"  {nodo}: {sorted(vecindad) if vecindad else 'vacía'}")
        
        print()
        print("Vecindades izquierdas:")
        for nodo in self.nodos:
            vecindad = self.vecindad_izquierda(nodo)
            print(f"  {nodo}: {sorted(vecindad) if vecindad else 'vacía'}")