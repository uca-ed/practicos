import json
from grafo_ej1 import Grafo
from collections import deque

class CaminosGrafo:
    def __init__(self, grafo):
        self.grafo = grafo
    
    def encontrar_camino_bfs(self, nodo_origen, nodo_destino):
        if nodo_origen not in self.grafo.nodo_a_indice or nodo_destino not in self.grafo.nodo_a_indice:
            return None
        
        if nodo_origen == nodo_destino:
            return [nodo_origen]
        
        visitados = set()
        cola = deque([(nodo_origen, [nodo_origen])])
        visitados.add(nodo_origen)
        
        while cola:
            nodo_actual, camino = cola.popleft()
            
            for vecino in self.grafo.vecindad_derecha(nodo_actual):
                if vecino not in visitados:
                    nuevo_camino = camino + [vecino]
                    
                    if vecino == nodo_destino:
                        return nuevo_camino
                    
                    visitados.add(vecino)
                    cola.append((vecino, nuevo_camino))
        
        return None
    
    def encontrar_camino_dfs(self, nodo_origen, nodo_destino):
        if nodo_origen not in self.grafo.nodo_a_indice or nodo_destino not in self.grafo.nodo_a_indice:
            return None
        
        visitados = set()
        
        def dfs_recursivo(nodo_actual, camino):
            if nodo_actual == nodo_destino:
                return camino
            
            visitados.add(nodo_actual)
            
            for vecino in self.grafo.vecindad_derecha(nodo_actual):
                if vecino not in visitados:
                    resultado = dfs_recursivo(vecino, camino + [vecino])
                    if resultado:
                        return resultado
            
            return None
        
        return dfs_recursivo(nodo_origen, [nodo_origen])

def main():
    print("Creando ejemplo de grafo con caminos:")
    nodos = ["1", "2", "3", "4", "5"]
    matriz = [
        [0, 1, 1, 0, 0],
        [0, 0, 0, 1, 0],
        [0, 1, 0, 0, 1],
        [0, 0, 0, 0, 1],
        [0, 0, 0, 0, 0]
    ]
    grafo = Grafo(nodos, matriz)
    caminos = CaminosGrafo(grafo)
    
    print(f"Grafo con {grafo.num_nodos} nodos")
    grafo.imprimir_matriz()
    print()
    
    origen = "1"
    destino = "5"
    camino = caminos.encontrar_camino_bfs(origen, destino)
    if camino:
        print(f"Camino de {origen} a {destino}: {' -> '.join(camino)}")
    else:
        print(f"No hay camino de {origen} a {destino}")
    
    origen2 = "2"
    destino2 = "3"
    camino2 = caminos.encontrar_camino_bfs(origen2, destino2)
    if camino2:
        print(f"Camino de {origen2} a {destino2}: {' -> '.join(camino2)}")
    else:
        print(f"No hay camino de {origen2} a {destino2}")

if __name__ == "__main__":
    main()