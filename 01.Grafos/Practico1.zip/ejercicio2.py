import json
from grafo_ej1 import Grafo

class PropiedadesGrafo:
    def __init__(self, grafo):
        self.grafo = grafo
    
    def es_reflexiva(self):
        for i in range(self.grafo.num_nodos):
            if self.grafo.matriz[i][i] != 1:
                return False
        return True
    
    def es_simetrica(self):
        for i in range(self.grafo.num_nodos):
            for j in range(self.grafo.num_nodos):
                if self.grafo.matriz[i][j] != self.grafo.matriz[j][i]:
                    return False
        return True
    
    def es_antisimetrica(self):
        for i in range(self.grafo.num_nodos):
            for j in range(self.grafo.num_nodos):
                if i != j and self.grafo.matriz[i][j] == 1 and self.grafo.matriz[j][i] == 1:
                    return False
        return True
    
    def es_transitiva(self):
        for i in range(self.grafo.num_nodos):
            for j in range(self.grafo.num_nodos):
                for k in range(self.grafo.num_nodos):
                    if self.grafo.matriz[i][j] == 1 and self.grafo.matriz[j][k] == 1:
                        if self.grafo.matriz[i][k] != 1:
                            return False
        return True
    
    def es_orden(self):
        return self.es_reflexiva() and self.es_antisimetrica() and self.es_transitiva()
    
    def es_equivalencia(self):
        return self.es_reflexiva() and self.es_simetrica() and self.es_transitiva()
    
    def verificar_propiedades(self):
        reflexiva = self.es_reflexiva()
        simetrica = self.es_simetrica()
        antisimetrica = self.es_antisimetrica()
        transitiva = self.es_transitiva()
        
        print("Propiedades del grafo:")
        print(f"Reflexiva: {reflexiva}")
        print(f"Simétrica: {simetrica}")
        print(f"Antisimétrica: {antisimetrica}")
        print(f"Transitiva: {transitiva}")
        print()
        
        if self.es_orden():
            print("El grafo ES un orden parcial")
        elif self.es_equivalencia():
            print("El grafo ES una relación de equivalencia")
        else:
            print("El grafo NO es orden ni equivalencia")
        print()

def main():
    print("Creando ejemplo de grafo reflexivo y transitivo:")
    nodos = ["a", "b", "c"]
    matriz = [
        [1, 1, 1],
        [0, 1, 1], 
        [0, 0, 1]
    ]
    grafo = Grafo(nodos, matriz)
    propiedades = PropiedadesGrafo(grafo)
    propiedades.verificar_propiedades()
    
    print("Creando ejemplo de grafo simétrico:")
    matriz2 = [
        [1, 1, 0],
        [1, 1, 1],
        [0, 1, 1]
    ]
    grafo2 = Grafo(nodos, matriz2)
    propiedades2 = PropiedadesGrafo(grafo2)
    propiedades2.verificar_propiedades()

if __name__ == "__main__":
    main()