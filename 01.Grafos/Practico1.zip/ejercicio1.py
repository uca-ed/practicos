from grafo_ej1 import Grafo
import os

def main():
    directorio_archivos = "archivos_ej1/archivos_ej1"
    archivos_csv = ["01.csv", "02.csv", "03.csv", "04.csv"]
    
    for archivo_csv in archivos_csv:
        ruta_archivo = os.path.join(directorio_archivos, archivo_csv)
        if os.path.exists(ruta_archivo):
            grafo = Grafo.desde_csv(ruta_archivo)
            print(f"Archivo: {archivo_csv}")
            grafo.imprimir_info()
            print()

    archivo_json = "01.json"
    ruta_json = os.path.join(directorio_archivos, archivo_json)
    
    if os.path.exists(ruta_json):
        grafo = Grafo.desde_json(ruta_json)
        print(f"Archivo JSON: {grafo.num_nodos} nodos")
        minimales = grafo.obtener_minimales()
        maximales = grafo.obtener_maximales()
        print(f"Minimales: {len(minimales)}, Maximales: {len(maximales)}")

if __name__ == "__main__":
    main()