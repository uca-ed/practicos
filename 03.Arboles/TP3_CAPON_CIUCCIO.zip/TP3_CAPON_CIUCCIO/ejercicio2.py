class Nodo:
    def __init__(self, clave):
        self.clave = clave
        self.izquierda = None
        self.derecha = None
        self.altura = 1

def altura(nodo):
    return nodo.altura if nodo else 0

def actualizar_altura(nodo):
    nodo.altura = 1 + max(altura(nodo.izquierda), altura(nodo.derecha))

def balance(nodo):
    return altura(nodo.izquierda) - altura(nodo.derecha)

def rotar_derecha(y):
    x = y.izquierda
    T2 = x.derecha

    x.derecha = y
    y.izquierda = T2

    actualizar_altura(y)
    actualizar_altura(x)

    return x

def rotar_izquierda(x):
    y = x.derecha
    T2 = y.izquierda

    y.izquierda = x
    x.derecha = T2

    actualizar_altura(x)
    actualizar_altura(y)

    return y

def insertar(nodo, clave):
    if not nodo:
        return Nodo(clave)
    elif clave < nodo.clave:
        nodo.izquierda = insertar(nodo.izquierda, clave)
    else:
        nodo.derecha = insertar(nodo.derecha, clave)

    actualizar_altura(nodo)
    balance_factor = balance(nodo)

    # ROTACIONES
    if balance_factor > 1:
        if clave < nodo.izquierda.clave:
            return rotar_derecha(nodo)  # Izquierda-Izquierda
        else:
            nodo.izquierda = rotar_izquierda(nodo.izquierda)
            return rotar_derecha(nodo)  # Izquierda-Derecha

    if balance_factor < -1:
        if clave > nodo.derecha.clave:
            return rotar_izquierda(nodo)  # Derecha-Derecha
        else:
            nodo.derecha = rotar_derecha(nodo.derecha)
            return rotar_izquierda(nodo)  # Derecha-Izquierda

    return nodo

def preorden(nodo):
    if not nodo:
        return []
    return [nodo.clave] + preorden(nodo.izquierda) + preorden(nodo.derecha)

def inorden(nodo):
    if not nodo:
        return []
    return inorden(nodo.izquierda) + [nodo.clave] + inorden(nodo.derecha)

def leer_csv_a_lista(nombre_archivo):
    datos = []
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            fila = linea.strip().split(',')
            datos.append(fila)
    return datos

def main():
    datos = leer_csv_a_lista("datos.csv")[0]

    raiz = None
    for valor in datos:
        raiz = insertar(raiz, valor)

    print("\nRECORRIDO PREORDEN DEL ARBOL AVL:", preorden(raiz))
    print("RECORRIDO INORDEN DEL ARBOL AVL:", inorden(raiz))
    print()
main()