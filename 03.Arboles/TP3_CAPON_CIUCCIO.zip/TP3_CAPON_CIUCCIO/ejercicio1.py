def calcularAlturaDelArbol(n, tipo):
    h = 0
    total_nodos = 0
    while True:
        total_nodos = (tipo ** (h + 1) - 1) // (tipo - 1)
        if total_nodos >= n:
            return h
        h += 1

def calcularRecorridoPreorden(arbol, d, indice, resultado):
    if indice >= len(arbol):
        return resultado

    resultado.append(arbol[indice])# INGRESA EL NODO ACTUAL AL RESULTADO

    for k in range(1, d + 1):# RECORRE EL ARBOL
        hijo_indice = d * indice + k
        if hijo_indice < len(arbol):
            calcularRecorridoPreorden(arbol, d, hijo_indice, resultado)

    return resultado


def leer_csv_a_lista(nombre_archivo):
    datos = []
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            fila = linea.strip().split(',')
            datos.append(fila)
    return datos

def main():
    # Datos de ejemplo
    arbol = leer_csv_a_lista("datos.csv")[0]
    BINARIO = 2

    print("\nLA ALTURA DEL ARBOL ES:", calcularAlturaDelArbol(len(arbol), BINARIO))

    print("EL RECORRIDO PREORDEN DEL ARBOL ES:", calcularRecorridoPreorden(arbol, BINARIO,0,[]))
    print()

main()