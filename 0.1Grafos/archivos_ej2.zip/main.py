import json

def leerJSON(nombreArchivo):
    with open(nombreArchivo) as f:
        data = json.load(f)

    nodos = list(map(int, data["P"]))
    n = len(nodos)
    matriz = [[0]*n for _ in range(n)]

    for origen in data["P"]:                    
        destinos = data["E"].get(origen, [])      
        for d in set(destinos):                  
            matriz[int(origen)-1][int(d)-1] = 1
    return matriz


def es_reflexiva(matriz):
    for i in range(len(matriz)):
        if matriz[i][i]!=1:
            return False
    return True

def es_simetrica(matriz):
    for i in range(len(matriz)):
        for j in range(len(matriz)):
            if matriz[i][j]!=matriz[j][i]:
                return False
    return True

def es_antisimetrica(matriz):
    for i in range(len(matriz)):
        for j in range(len(matriz)):
            if i!=j and matriz[i][j]==1 and matriz[j][i]==1:
                return False
    return True

def es_transitiva(matriz):
    for i in range(len(matriz)):
        for j in range(len(matriz)):
            if(matriz[i][j])==1:
                for k in range(len(matriz)):
                    if(matriz[j][k]==1):
                        if(matriz[i][k]==0):
                            return False
    return True

def relacionDeEquivalencia(matriz):
    return es_reflexiva(matriz) and es_simetrica(matriz) and es_transitiva(matriz)

def ordenParcial(matriz):
    return es_reflexiva(matriz) and es_antisimetrica(matriz) and es_transitiva(matriz)

def main():
    matriz1=leerJSON("01.json")
    matriz2=leerJSON("02.json")
    matriz3=leerJSON("03.json")
    matriz=matriz1

    # if(es_antisimetrica(matriz)):
    #     print("La relacion es antisimetrica")
    # if(es_simetrica(matriz)):
    #     print("La relacion es simetrica")
    # if(es_reflexiva(matriz)):
    #     print("La relacion es reflexiva")
    # if(es_transitiva(matriz)):
    #     print("La relacion es transitiva")

    if(relacionDeEquivalencia(matriz)):
        print("La relacion es de equivalencia")
    if(ordenParcial(matriz)):
        print("La relacion es un orden parcial")


main()