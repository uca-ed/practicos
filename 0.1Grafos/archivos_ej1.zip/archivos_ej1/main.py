import csv
import json

def leerCSV(nombreArchivo):
    lsl=[]
    arch = open(nombreArchivo, "r")
    lst = arch.readlines()
    #print(lst)
    print("\n")

    for linea in lst:
        fila=list(map(int, linea.strip().split(",")))
        lsl.append(fila)

    print(lsl)
    arch.close()
    return lsl

def leerJSON(nombreArchivo):
    with open(nombreArchivo) as f:
        data = json.load(f)

    nodos = list(map(int, data["P"]))
    n = len(nodos)
    matriz = [[0]*n for _ in range(n)]

    for origen in data["P"]:                    
        destinos = data["E"].get(origen, [])      
        for d in set(destinos):                  
            matriz[int(origen)-1][int(d)-1] = 1
    return matriz

def minimal(matriz):
    listaDeColumnas=[]
    for i in range(len(matriz[0])):
        columna=[fila[i] for fila in matriz]
        listaDeColumnas.append(columna)

    #print("Matriz original= ",matriz)
    print("Matriz de columnas= ",listaDeColumnas)

    nodosMinimales=[]
    numCol=0
    for columna in listaDeColumnas:
        sumatoriaDeColuma=0
        numCol+=1
        for i in range(len(columna)):
            sumatoriaDeColuma=sumatoriaDeColuma+columna[i]
        if(sumatoriaDeColuma==0):
            nodosMinimales.append(numCol)

    print("Nodos minimales= ",nodosMinimales)

def maximal(matriz):
    nodosMaximales=[]
    numFila=0
    for fila in matriz:
        sumatoriaDeFila=0
        numFila+=1
        for i in range(len(fila)):
            sumatoriaDeFila=sumatoriaDeFila+fila[i]
        if(sumatoriaDeFila==0):
            nodosMaximales.append(numFila)

    print("Nodos maximales= ",nodosMaximales)
    
def vecindadDer(nodo,matriz):
    VecindadDerecha=[]
    lst=matriz[nodo-1]
    for i in range(len(lst)):
        if(lst[i]==1):
            VecindadDerecha.append(i+1)
    print("Vecindad derecha del nodo ",nodo," = ",VecindadDerecha)

def vecindadIzq(nodo,matriz):
    listaDeColumnas=[]
    for i in range(len(matriz[0])):
        columna=[fila[i] for fila in matriz]
        listaDeColumnas.append(columna)

    #print("Matriz original= ",matriz)
    print("Matriz de columnas= ",listaDeColumnas)

    VecindadIzquierda=[]
    lst=listaDeColumnas[nodo-1]
    for i in range(len(lst)):
        if(lst[i]==1):
            VecindadIzquierda.append(i+1)
    print("Vecindad derecha del nodo ",nodo," = ",VecindadIzquierda)

def main():
    #matriz1=leerCSV("01.csv")
    #matriz2=leerCSV("02.csv")
    #matriz3=leerCSV("03.csv")
    #matriz4=leerCSV("04.csv")
    matriz5=leerJSON("01.json")

    # minimal(matriz1)
    # minimal(matriz2)
    # minimal(matriz3)
    # minimal(matriz4)
    # minimal(matriz5)

    # maximal(matriz1)
    #maximal(matriz2)  
    # maximal(matriz3)
    # maximal(matriz4)  
    # maximal(matriz5)

    #vecindadDer(1,matriz2)
    #vecindadDer(2,matriz2)

    #vecindadIzq(1,matriz4)
    #vecindadIzq(2,matriz4)


main()