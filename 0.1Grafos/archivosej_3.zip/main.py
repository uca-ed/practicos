from collections import deque
import json

def busqueda_paso(matriz, origen, destino):
    n = len(matriz)
    origen -= 1
    destino -= 1

    OPEN = deque([(origen, None)])
    CLOSED = {}

    while OPEN:
        z, y = OPEN.popleft()
        CLOSED[z] = y

        for w, val in enumerate(matriz[z]):
            if val == 1 and w == destino:
                CLOSED[w] = z
                camino = []
                nodo = destino
                while nodo is not None:
                    camino.append(nodo+1)
                    nodo = CLOSED.get(nodo, None)
                return camino[::-1]

        for w, val in enumerate(matriz[z]):
            if val == 1 and w not in CLOSED and all(w != nodo for nodo, _ in OPEN):
                OPEN.append((w, z))

    return None


def leerJSON(nombreArchivo):
    with open(nombreArchivo) as f:
        data = json.load(f)

    nodos = list(map(int, data["P"]))
    n = len(nodos)
    matriz = [[0]*n for _ in range(n)]

    for origen in data["P"]:                    
        destinos = data["E"].get(origen, [])      
        for d in set(destinos):                  
            matriz[int(origen)-1][int(d)-1] = 1
    return matriz

    

def main():
    matriz = leerJSON("esDivisorDe-200.json")
    origen = 3
    destino = 100
    camino = busqueda_paso(matriz, origen, destino)
    print(camino)

main()