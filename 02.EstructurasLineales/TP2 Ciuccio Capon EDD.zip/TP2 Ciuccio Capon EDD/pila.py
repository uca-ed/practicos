class Pila:
    def __init__(self, capacidad=100):
        self.items = [None] * capacidad
        self.tope = -1
        self.capacidad = capacidad

    def push(self, item):
        if self.tope + 1 == self.capacidad:
            print("Pila llena. No se puede apilar", item)
            return
        self.tope += 1
        self.items[self.tope] = item

    def pop(self):
        if self.tope == -1:
            print("Pila vacía. No se puede desapilar")
            return None
        valor = self.items[self.tope]
        self.tope -= 1
        return valor

    def mostrar(self):
        if self.tope == -1:
            return "(vacía)"
        return " <- ".join(str(self.items[i]) for i in range(self.tope, -1, -1))

def procesar_archivo(nombre_archivo):
    pila = Pila()
    with open(nombre_archivo, "r") as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if not partes:
                continue
            operacion = partes[0]
            if operacion == "PUSH":
                pila.push(partes[1])
            elif operacion == "POP":
                pila.pop()
            else:
                print("Operación desconocida:", operacion)
    print("Contenido final de la pila (tope a izquierda):")
    print(pila.mostrar())

if __name__ == "__main__":
    procesar_archivo("operaciones_pila.txt")
