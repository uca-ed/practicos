import numpy as np

DIM = {
    'edificios': 4,
    'pisos': 5,
    'alas': 2,
    'aulas': 25,
    'bloques': 17
}

def calcular_indice(d0, d1, d2, d3, d4):
    return (
        d0 * DIM['pisos'] * DIM['alas'] * DIM['aulas'] * DIM['bloques'] +
        d1 * DIM['alas'] * DIM['aulas'] * DIM['bloques'] +
        d2 * DIM['aulas'] * DIM['bloques'] +
        d3 * DIM['bloques'] +
        d4
    )

def cargar_datos(nombre_archivo):
    vector = np.zeros(DIM['edificios'] * DIM['pisos'] * DIM['alas'] * DIM['aulas'] * DIM['bloques'], dtype=int)
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            d0, d1, d2, d3, d4, valor = map(int, linea.strip().split())
            idx = calcular_indice(d0, d1, d2, d3, d4)
            vector[idx] = valor
    return vector

def aula_max_ocupacion(inscriptos, capacidad):
    max_porcentaje = -1
    mejor_idx = None
    for i in range(len(inscriptos)):
        if capacidad[i] > 0:
            porcentaje = inscriptos[i] / capacidad[i]
            if porcentaje > max_porcentaje:
                max_porcentaje = porcentaje
                mejor_idx = i
    return mejor_idx, max_porcentaje

def promedio_por_piso(inscriptos, bloque_horario):
    promedios = []
    for piso in range(DIM['pisos']):
        total = 0
        cantidad = 0
        for edificio in range(DIM['edificios']):
            for ala in range(DIM['alas']):
                for aula in range(DIM['aulas']):
                    idx = calcular_indice(edificio, piso, ala, aula, bloque_horario)
                    total += inscriptos[idx]
                    cantidad += 1
        promedios.append(total / cantidad if cantidad > 0 else 0)
    return promedios

def total_por_ala(inscriptos, edificio, piso, bloque):
    total_norte = 0
    total_sur = 0
    for ala in range(DIM['alas']):
        for aula in range(DIM['aulas']):
            idx = calcular_indice(edificio, piso, ala, aula, bloque)
            if ala == 0:
                total_norte += inscriptos[idx]
            else:
                total_sur += inscriptos[idx]
    return total_norte, total_sur

if __name__ == "__main__":
    inscriptos = cargar_datos("inscriptos.txt")
    capacidad = cargar_datos("capacidad.txt")

    idx_max, porc_max = aula_max_ocupacion(inscriptos, capacidad)
    print(f"Aula con mayor porcentaje de ocupación: índice {idx_max} ({porc_max:.2%})")

    bloque = 5
    print(f"Promedio de alumnos por piso en el bloque horario {bloque}:")
    for i, prom in enumerate(promedio_por_piso(inscriptos, bloque)):
        print(f"  Piso {i}: {prom:.2f} alumnos")

    edificio = 1
    piso = 2
    bloque = 7
    norte, sur = total_por_ala(inscriptos, edificio, piso, bloque)
    print(f"Total de alumnos en Edificio {edificio}, Piso {piso}, Bloque {bloque}:")
    print(f"  Ala Norte: {norte}")
    print(f"  Ala Sur: {sur}")
