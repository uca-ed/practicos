
class Cola:
    def __init__(self, capacidad=100):
        self.items = [None] * capacidad
        self.frente = 0
        self.final = -1
        self.tamanio = 0
        self.capacidad = capacidad

    def enqueue(self, item):
        if self.tamanio == self.capacidad:
            print("Cola llena. No se puede encolar", item)
            return
        self.final = (self.final + 1) % self.capacidad
        self.items[self.final] = item
        self.tamanio += 1

    def dequeue(self):
        if self.tamanio == 0:
            print("Cola vacía. No se puede desencolar")
            return None
        valor = self.items[self.frente]
        self.frente = (self.frente + 1) % self.capacidad
        self.tamanio -= 1
        return valor

    def mostrar(self):
        resultado = []
        for i in range(self.tamanio):
            idx = (self.frente + i) % self.capacidad
            resultado.append(str(self.items[idx]))
        return " <- ".join(resultado)

def procesar_archivo(nombre_archivo):
    cola = Cola()
    with open(nombre_archivo, "r") as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if not partes:
                continue
            operacion = partes[0]
            if operacion == "ENQUEUE":
                cola.enqueue(partes[1])
            elif operacion == "DEQUEUE":
                cola.dequeue()
            else:
                print("Operación desconocida:", operacion)
    print("Contenido final de la cola:")
    print(cola.mostrar())

if __name__ == "__main__":
    procesar_archivo("operaciones_cola.txt")
