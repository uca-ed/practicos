from collections import deque

def leer_alfabetos(nombre_archivo):
    with open(nombre_archivo, 'r') as archivo:
        alfabetos = [line.strip() for line in archivo.readlines()]
    return alfabetos

def leer_palabras(nombre_archivo):
    with open(nombre_archivo, 'r') as archivo:
        palabras = [line.strip() for line in archivo.readlines()]
    return palabras

def radix_sort(palabras, alfabetos):
    max_len = len(alfabetos)
    r = len(alfabetos[0]) 

  
    palabras = [p.rjust(max_len) for p in palabras]

    for pos in reversed(range(max_len)):
        orden = alfabetos[pos]
        cubetas = {letra: deque() for letra in orden}
        cubetas[' '] = deque() 

        for palabra in palabras:
            char = palabra[pos] if pos < len(palabra) else ' '
            if char not in cubetas:
                cubetas[char] = deque()  
            cubetas[char].append(palabra)

        palabras = []
        for letra in orden + ' ':
            palabras.extend(cubetas[letra])
    return [p.strip() for p in palabras]

if __name__ == "__main__":
    alfabetos = leer_alfabetos("alfabeto.txt")
    palabras = leer_palabras("palabras.txt")
    resultado = radix_sort(palabras, alfabetos)
    print("Palabras ordenadas:")
    for palabra in resultado:
        print(palabra)
