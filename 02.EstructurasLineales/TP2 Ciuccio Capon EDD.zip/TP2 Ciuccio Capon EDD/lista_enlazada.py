class Nodo:
    def __init__(self, dato):
        self.dato = dato
        self.siguiente = None

class ListaEnlazada:
    def __init__(self):
        self.cabeza = None

    def insertar_al_final(self, dato):
        nuevo = Nodo(dato)
        if self.cabeza is None:
            self.cabeza = nuevo
        else:
            actual = self.cabeza
            while actual.siguiente:
                actual = actual.siguiente
            actual.siguiente = nuevo

    def insertar_al_inicio(self, dato):
        nuevo = Nodo(dato)
        nuevo.siguiente = self.cabeza
        self.cabeza = nuevo

    def eliminar(self, dato):
        actual = self.cabeza
        anterior = None
        while actual:
            if actual.dato == dato:
                if anterior:
                    anterior.siguiente = actual.siguiente
                else:
                    self.cabeza = actual.siguiente
                return True
            anterior = actual
            actual = actual.siguiente
        return False

    def mostrar(self):
        elementos = []
        actual = self.cabeza
        while actual:
            elementos.append(str(actual.dato))
            actual = actual.siguiente
        return " -> ".join(elementos) if elementos else "(vacía)"

if __name__ == "__main__":
    lista = ListaEnlazada()
    lista.insertar_al_final("A")
    lista.insertar_al_final("B")
    lista.insertar_al_final("C")
    print("Lista después de insertar al final:")
    print(lista.mostrar())

    lista.insertar_al_inicio("X")
    print("Lista después de insertar al inicio:")
    print(lista.mostrar())

    lista.eliminar("B")
    print("Lista después de eliminar 'B':")
    print(lista.mostrar())
