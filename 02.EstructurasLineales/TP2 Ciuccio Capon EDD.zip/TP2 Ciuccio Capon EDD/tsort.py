from collections import defaultdict, deque

def leer_grafo(nombre_archivo):
    grafo = defaultdict(list)
    grados_entrada = defaultdict(int)
    nodos = set()

    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            if linea.strip():
                origen, destino = linea.strip().split()
                grafo[origen].append(destino)
                grados_entrada[destino] += 1
                nodos.update([origen, destino])

    for nodo in nodos:
        grados_entrada[nodo]  

    return grafo, grados_entrada, nodos

def tsort(grafo, grados_entrada, nodos):
    cola = deque([n for n in nodos if grados_entrada[n] == 0])
    resultado = []

    while cola:
        nodo = cola.popleft()
        resultado.append(nodo)
        for vecino in grafo[nodo]:
            grados_entrada[vecino] -= 1
            if grados_entrada[vecino] == 0:
                cola.append(vecino)

    if len(resultado) != len(nodos):
        print("El grafo es cíclico. No se puede aplicar sort topológico.")
    else:
        print("Sort topológico:")
        print(" -> ".join(resultado))

if __name__ == "__main__":
    grafo, grados_entrada, nodos = leer_grafo("grafo_tsort.txt")
    tsort(grafo, grados_entrada, nodos)
