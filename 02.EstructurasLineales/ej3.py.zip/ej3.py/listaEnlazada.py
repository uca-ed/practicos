from nodo import Nodo

class ListaEnlazada:
    def __init__(self,):
        self.cabeza = None
    
    def agregar(self, dato):
        nuevoNodo=Nodo(dato)
        
        if self.cabeza is None:
            self.cabeza=nuevoNodo
        elif self.cabeza is not None:
            actual=self.cabeza
            while actual.siguiente:
                actual=actual.siguiente
            actual.siguiente=nuevoNodo

    def imprimir(self):
        actual=self.cabeza
        while actual:
            if actual.siguiente:
                print(actual.dato, end=" -> ")
            else:
                print(actual.dato)
            actual=actual.siguiente 


