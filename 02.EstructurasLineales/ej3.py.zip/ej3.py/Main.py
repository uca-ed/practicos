from listaEnlazada import ListaEnlazada

def main():
    listaEnlazada=ListaEnlazada()
    listaEnlazada.agregar(10)
    listaEnlazada.agregar(20)
    listaEnlazada.agregar(30)
    listaEnlazada.imprimir()

main()